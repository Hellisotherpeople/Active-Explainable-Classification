# Accelerator

## Design 
1. each one is working on the src/component dir
2. each component is independent on code and dev env
3. each component is pkg into a docker file and running the k8s

## Tests
TODO
   

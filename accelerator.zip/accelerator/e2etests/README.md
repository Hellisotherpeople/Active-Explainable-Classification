## Installation Instructions

### 1. Set Up a Python Virtual Environment
Create a new environment and activate it using Conda:
```bash
conda create -n ag2 python=3.11 && conda activate ag2
```

### 2. Install Dependencies
Install the project dependencies:
```bash
pip install ag2[autobuild]==0.7.0,pandas,sentence_transformers
```
or if you run into issue to install this downgrade python package, please use 
``
conda install -c conda-forge pyautogen==0.7.0
``

### 3. How to run the test with different model name
``
python workflow_test.py --model_name /data/models/mistralai/Mistral-Large-Instruct-2411
``

model_name can be gpt-4o, gpt-40-mini, /data/models/Qwen/QwQ-32B-Preview, /data/models/mistralai/Mistral-Large-Instruct-2411

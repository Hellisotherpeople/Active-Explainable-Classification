import autogen
from utils import build_llm_config
from autogen.agentchat.contrib.capabilities.teachability import Teachability
from tqdm import tqdm
from rich import print as rprint
from rich.panel import Panel
from rich.console import Console

console = Console()

##Need to downgrade autogen to 0.7.0 and install autogen[autobuild] / ag2[autobuild]

##so pip install autogen[autobuild]==0.7.0
class Network:
    def __init__(self, llm_config, code_execute_model=True):
        console.print("[bold blue]🔄 Initializing Network...[/bold blue]")
        self.agents = []
        # Disable caching by setting cache_seed to None
        llm_config["cache_seed"] = None
        self.llm_config = llm_config
        self.tool_agent = None
        self.code_execute_model = code_execute_model

        with console.status("[bold green]Initializing base agents...") as status:
            # Initialize base agents
            self.planner = autogen.AssistantAgent(
                name="Planner",
                system_message="""Planner. Suggest a plan. Revise the plan based on feedback from admin, until admin approval.
            The plan may involve an engineer who can write code and a scientist who doesn't write code.
            Explain the plan first. Be clear which step is performed by an engineer, and which step is performed by a scientist.
            """,
                llm_config=llm_config,
            )

            if self.code_execute_model:
                self.executor = autogen.UserProxyAgent(
                    name="Executor",
                    system_message="Executor. Execute the code written by the engineer and report the result.",
                    human_input_mode="NEVER",
                    code_execution_config={
                        "last_n_messages": 3,
                        "work_dir": "executor",
                        "use_docker": False,
                    },
                )
            else:
                # this is used for debug only
                self.executor = autogen.UserProxyAgent(
                    name="Executor",
                    system_message="Executor. Simulate to run the code written by the engineer and report the simulation result.",
                    human_input_mode="NEVER",
                    code_execution_config=False
                )

            self.engineer = autogen.AssistantAgent(
                name="Engineer",
                llm_config=llm_config,
                system_message="""Engineer. You follow an approved plan. You write python/shell code to solve tasks. 
                Wrap the code in a code block that specifies the script type. The user can't modify your code. 
                So do not suggest incomplete code which requires others to modify. Don't use a code block if it's not intended to be executed by the executor.
                Don't include multiple code blocks in one response. Do not ask others to copy and paste the result. 
                Check the execution result returned by the executor.
                If the result indicates there is an error, fix the error and output the code again. 
                Suggest the full code instead of partial code or code changes. 
                If the error can't be fixed or if the task is not solved even after the code is executed successfully, analyze the problem, revisit your assumption, collect additional info you need, and think of a different approach to try.
            """,
            )
            status.update("[bold green]✓ Base agents initialized successfully")

    def add_agent(self, agent):
        self.agents.append(agent)
        console.print(f"[green]➕ Added new agent: {agent.name}[/green]")

    def list_agents(self):
        console.print("\n[bold cyan]🤖 Network Agents:[/bold cyan]")
        for agent in self.agents:
            console.print(f"[cyan]└─ {agent.name}[/cyan]")

    def add_tool_provider(self, agent):
        self.tool_agent = agent
        console.print(f"[green]🛠️ Tool provider added: {agent.name}[/green]")

    def run_initial_task(self, user_prompt):
        console.print(Panel.fit("[bold blue]🚀 Initiating Task Execution[/bold blue]"))
        
        user_proxy = autogen.UserProxyAgent(
            name="Admin",
            system_message="A human admin. Interact with the planner to discuss the plan. Plan execution needs to be approved by this admin.",
            code_execution_config=False,
        )

        with console.status("[bold yellow]Setting up group chat...") as status:
            groupchat = autogen.GroupChat(
                agents=[user_proxy, self.engineer, self.tool_agent, self.planner, self.executor], 
                messages=[], 
                max_round=5000
            )
            manager = autogen.GroupChatManager(groupchat=groupchat, llm_config=self.llm_config)
            status.update("[bold green]✓ Group chat ready")

        user_proxy.initiate_chat(
            manager,
            message=user_prompt,
        )

    def run_group_chat(self, tool_agent, agent_list, sys_message):
        console.print(Panel.fit("[bold blue]🤝 Starting Group Discussion[/bold blue]"))

        with console.status("[bold yellow]Configuring agent capabilities...") as status:
            teachability_configs = [
                ("engineer", self.engineer),
                ("tool", tool_agent),
                ("executor", self.executor)
            ]
            
            for name, agent in tqdm(teachability_configs, desc="Adding teachability"):
                teachability = Teachability(
                    reset_db=True,
                    path_to_db_dir=f"./tmp/interactive/teachability_db_{name}",
                    llm_config=self.llm_config
                )
                teachability.add_to_agent(agent)
                
            status.update("[bold green]✓ Agent capabilities configured")

        # Combine built agents with existing ones
        agents = [self.engineer, tool_agent, self.executor] + agent_list
        
        with console.status("[bold yellow]Initializing group chat...") as status:
            groupchat = autogen.GroupChat(agents=agents, messages=[], max_round=5000)
            manager = autogen.GroupChatManager(groupchat=groupchat, llm_config=self.llm_config)

            # Add teachability to manager
            teachability_manager = Teachability(
                reset_db=True,
                path_to_db_dir=f"./tmp/interactive/teachability_db_manager",
                llm_config=self.llm_config
            )
            teachability_manager.add_to_agent(manager)
            status.update("[bold green]✓ Group chat initialized")

        console.print("\n[bold cyan]💬 Starting Discussion[/bold cyan]")
        result = manager.initiate_chat(
            manager,
            message=sys_message,
        )

        return result


if __name__ == "__main__":
    model = "gpt-4o-mini"
    # model = "/data/models/Qwen/QwQ-32B-Preview"

    console.print(Panel.fit("[bold blue]🌟 Network Test Environment[/bold blue]"))
    
    with console.status("[bold green]Building LLM configuration...") as status:
        llm_config = build_llm_config(model)
        test_network = Network(llm_config)
        status.update("[bold green]✓ Test environment ready")
    
    # test_network.test_eng_tools_discuss()


import autogen

config_list = [
    {
        'model': 'gpt-4o-mini',
        'api_key': '8e7d5aa9808d4b69a8166f65ce77930d',
        "base_url": "https://wand-production-azure-openai-us-west.openai.azure.com/",
        'api_type': 'azure',
        "api_version": "2024-05-01-preview",
    },
    {
        'model': '/data/models/Qwen/QwQ-32B-Preview',
        'api_key': 'sk-ZxyVUjjirsVwcSii64E2949dF7444f5fB1883bB543E60b0d',
        'base_url': 'http://195.242.10.142:30007/v1',  # This for local model
    },
    {
        'model': 'gpt-4o',
        'api_key': '580813d2e3ab46c8a9c848355a4110ce',
        'base_url': 'https://wand-production-us-west-3.openai.azure.com/',
        'api_type': 'azure',
        'api_version': '2024-08-01-preview',
    },
]


# Function to filter a specific model
def get_config_by_model(config_list, model_name):
    for config in config_list:
        if config['model'] == model_name:
            return config
    return None  # Return None if no matching model is found


# Example usage
selected_model = '/data/models/Qwen/QwQ-32B-Preview'

config = get_config_by_model(config_list, selected_model)

if config:
    print(f"Configuration for {selected_model}:")
    print(config)
else:
    print(f"No configuration found for model: {selected_model}")

config_list = [config]

llm_config = {"temperature": 0, "config_list": config_list}

user_proxy = autogen.UserProxyAgent(
    name="user_proxy",
    system_message="A human admin, analyze the plan and interact with different agents to discuss the plan, and finally give a solution.",
    code_execution_config={
        "last_n_messages": 3,
        "work_dir": "groupchat",
        "use_docker": False,
    },
    human_input_mode="TERMINATE",
)

# Investment Strategist Agent
InvestmentStrategistAgent = autogen.AssistantAgent(
    name="investment_strategist_agent",
    system_message=(
        "You are an Investment Strategist Agent responsible for developing and refining investment strategies. "
        "You utilize market analysis tools, backtesting frameworks, and risk assessment models to ensure strategies align with company risk tolerance and financial goals. "
        "You are scheduled to provide daily or weekly updates on market trends and collaborate with the Risk Manager and Data Analyst for strategy refinement."
    ),
    llm_config=llm_config,
    description="An agent specializing in developing and refining investment strategies using market analysis tools, backtesting frameworks, and risk assessment models."
)

# Data Analyst Agent
DataAnalystAgent = autogen.AssistantAgent(
    name="Data_Analyst_Agent",
    system_message=(
        "You are a Data Analyst Agent responsible for collecting and analyzing historical market data to support investment strategies. "
        "You use tools for data collection, statistical analysis, and machine learning to identify patterns and insights. "
        "You ensure data integrity and provide automated daily data reports to the Investment Strategist and Performance Evaluator."
    ),
    code_execution_config={
        "last_n_messages": 3,
        "work_dir": "analysis",
        "use_docker": False,
    },
    llm_config=llm_config,
    description="An agent specializing in data collection, statistical analysis, and machine learning to support investment strategies while ensuring data integrity. You can use the tools to do machine learning or data analysis"
)

# Risk Manager Agent
RiskManagerAgent = autogen.AssistantAgent(
    name="Risk_Manager_Agent",
    system_message=(
        "You are a Risk Manager Agent responsible for assessing and managing financial risks associated with investment strategies. "
        "You utilize risk assessment models like Value at Risk and stress testing, monitor compliance through regulatory databases, and develop risk mitigation plans. "
        "You continuously monitor financial health indicators and collaborate with the Investment Strategist and Financial Planner to align risk management with financial goals."
    ),
    llm_config=llm_config,
    description="An agent specializing in risk assessment, compliance monitoring, and risk mitigation to manage financial risks and ensure alignment with financial goals."
)

# Performance Evaluator Agent
PerformanceEvaluatorAgent = autogen.AssistantAgent(
    name="Performance_Evaluator_Agent",
    system_message=(
        "You are a Performance Evaluator Agent responsible for tracking the performance of investment strategies. "
        "You use tools like dashboards and KPIs to monitor performance, compare current performance with historical benchmarks, and provide feedback and recommendations for strategy improvement. "
        "You perform daily evaluations and collaborate with the Investment Strategist to enhance strategies."
    ),
    code_execution_config={
        "last_n_messages": 3,
        "work_dir": "performance",
        "use_docker": False,
    },
    llm_config=llm_config,
    description="An agent specializing in tracking and evaluating the performance of investment strategies, providing insights and recommendations for improvement."
)

# Financial Planner Agent
FinancialPlannerAgent = autogen.AssistantAgent(
    name="Financial_Planner_Agent",
    system_message=(
        "You are a Financial Planner Agent responsible for managing earnings allocation and supporting company growth and sustainability. "
        "You use financial modeling tools for cash flow forecasting, budgeting software for managing earnings, and frameworks for developing growth strategies. "
        "You monitor cash flow regularly and coordinate with the Risk Manager to ensure financial stability."
    ),
    llm_config=llm_config,
    description="An agent specializing in financial modeling, budgeting, and growth strategy development to ensure earnings allocation and financial stability."
)

coder = autogen.AssistantAgent(
    name="Coder",
    llm_config=llm_config,
)

groupchat = autogen.GroupChat(
    agents=[user_proxy, FinancialPlannerAgent, InvestmentStrategistAgent, RiskManagerAgent, coder, DataAnalystAgent, PerformanceEvaluatorAgent,
            ], messages=[], max_round=5, allow_repeat_speaker=False)

manager = autogen.GroupChatManager(groupchat=groupchat, llm_config=llm_config)

if __name__ == "__main__":
    user_proxy.initiate_chat(
        manager,
        message="Establish an investment company with an initial budget of $100,000. From your earnings, 20% will be reinvested to grow your budget, while 80% returns to the owner. Your primary goal is to increase the performance of your strategy over time and in frequent periods, to ensure survival and evolution, avoiding budget depletion at all costs. You need to constantly improve your strategies to continuously increase returns and become better than your last version on a daily basis (we can evaluate the new strategy on past data while avoiding data leakage). please use the real market data from 2024-01 to now and run the results. I want to see how the final output ",
    )